#include <iostream>
int main() {
    using namespace std;
    cout << "This is Rahul' package to print a message\n";
}
